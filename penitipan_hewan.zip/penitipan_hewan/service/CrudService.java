package penitipan_hewan.service;

import penitipan_hewan.model.*;
import java.util.ArrayList;
import java.util.Scanner;

public class CrudService {
    private final ArrayList<Hewan> daftarHewan = new ArrayList<>();
    private final ArrayList<Pemilik> daftarPemilik = new ArrayList<>();
    private final ArrayList<Petugas> daftarPetugas = new ArrayList<>();
    private final ArrayList<Transaksi> daftarTransaksi = new ArrayList<>();
    private final Scanner scanner;

    // scanner disuntik dari MainApp agar tidak ada beberapa Scanner(System.in)
    public CrudService(Scanner scanner) {
        this.scanner = scanner;
    }

    // ------------------ HEWAN ------------------
    public void tambahHewan() {
        System.out.print("Nama hewan: ");
        String nama = scanner.nextLine();
        System.out.print("Jenis hewan: ");
        String jenis = scanner.nextLine();
        System.out.print("Umur hewan (tahun): ");
        int umur = readIntSafe();
        daftarHewan.add(new Hewan(nama, jenis, umur));
        System.out.println("✅ Hewan berhasil ditambahkan!");
    }

    public void lihatHewan() {
        System.out.println("\n📋 Daftar Hewan:");
        if (daftarHewan.isEmpty()) {
            System.out.println("Belum ada hewan.");
            return;
        }
        for (int i = 0; i < daftarHewan.size(); i++) {
            System.out.println((i + 1) + ". " + daftarHewan.get(i));
        }
    }

    public void ubahHewan() {
        lihatHewan();
        if (daftarHewan.isEmpty()) return;
        System.out.print("Masukkan nomor hewan yang ingin diubah: ");
        int idx = readIntSafe();
        if (!validIndex(idx, daftarHewan.size())) {
            System.out.println("Nomor tidak valid.");
            return;
        }
        Hewan h = daftarHewan.get(idx - 1);

        System.out.print("Nama baru (" + h.getNama() + ") [tekan Enter untuk tetap]: ");
        String namaBaru = scanner.nextLine();
        if (!namaBaru.isEmpty()) h.setNama(namaBaru);

        System.out.print("Jenis baru (" + h.getJenis() + ") [tekan Enter untuk tetap]: ");
        String jenisBaru = scanner.nextLine();
        if (!jenisBaru.isEmpty()) h.setJenis(jenisBaru);

        System.out.print("Umur baru (" + h.getUmur() + ") [tekan Enter untuk tetap]: ");
        String umurStr = scanner.nextLine();
        if (!umurStr.isEmpty()) {
            try { h.setUmur(Integer.parseInt(umurStr)); }
            catch (NumberFormatException e) { System.out.println("Input umur invalid, tetap menggunakan nilai lama."); }
        }

        System.out.println("✅ Data hewan berhasil diubah!");
    }

    public void hapusHewan() {
        lihatHewan();
        if (daftarHewan.isEmpty()) return;
        System.out.print("Masukkan nomor hewan yang akan dihapus: ");
        int idx = readIntSafe();
        if (validIndex(idx, daftarHewan.size())) {
            daftarHewan.remove(idx - 1);
            System.out.println("✅ Hewan berhasil dihapus!");
        } else System.out.println("Nomor tidak valid.");
    }
    
    public void cariHewan() {
    System.out.print("Masukkan kata kunci pencarian hewan: ");
    String key = scanner.nextLine().toLowerCase();
    boolean ditemukan = false;
    for (Hewan h : daftarHewan) {
        if (h.getNama().toLowerCase().contains(key) ||
            h.getJenis().toLowerCase().contains(key)) {
            System.out.println(h);
            ditemukan = true;
        }
    }
    if (!ditemukan) System.out.println("❌ Hewan tidak ditemukan.");
}

    // ------------------ PEMILIK ------------------
    public void tambahPemilik() {
        System.out.print("Nama pemilik: ");
        String nama = scanner.nextLine();
        System.out.print("Alamat: ");
        String alamat = scanner.nextLine();
        System.out.print("No HP: ");
        String hp = scanner.nextLine();
        daftarPemilik.add(new Pemilik(nama, alamat, hp));
        System.out.println("✅ Pemilik berhasil ditambahkan!");
    }

    public void lihatPemilik() {
        System.out.println("\n📋 Daftar Pemilik:");
        if (daftarPemilik.isEmpty()) {
            System.out.println("Belum ada pemilik.");
            return;
        }
        for (int i = 0; i < daftarPemilik.size(); i++) {
            System.out.println((i + 1) + ". " + daftarPemilik.get(i));
        }
    }

    public void ubahPemilik() {
        lihatPemilik();
        if (daftarPemilik.isEmpty()) return;
        System.out.print("Masukkan nomor pemilik yang ingin diubah: ");
        int idx = readIntSafe();
        if (!validIndex(idx, daftarPemilik.size())) {
            System.out.println("Nomor tidak valid.");
            return;
        }
        Pemilik p = daftarPemilik.get(idx - 1);

        System.out.print("Nama baru (" + p.getNama() + ") [tekan Enter untuk tetap]: ");
        String n = scanner.nextLine(); if (!n.isEmpty()) p.setNama(n);

        System.out.print("Alamat baru (" + p.getAlamat() + ") [tekan Enter untuk tetap]: ");
        String a = scanner.nextLine(); if (!a.isEmpty()) p.setAlamat(a);

        System.out.print("No HP baru (" + p.getNoHp() + ") [tekan Enter untuk tetap]: ");
        String hp = scanner.nextLine(); if (!hp.isEmpty()) p.setNoHp(hp);

        System.out.println("✅ Data pemilik berhasil diubah!");
    }

    public void hapusPemilik() {
        lihatPemilik();
        if (daftarPemilik.isEmpty()) return;
        System.out.print("Masukkan nomor pemilik yang akan dihapus: ");
        int idx = readIntSafe();
        if (validIndex(idx, daftarPemilik.size())) {
            daftarPemilik.remove(idx - 1);
            System.out.println("✅ Pemilik berhasil dihapus!");
        } else System.out.println("Nomor tidak valid.");
    }

    public void cariPemilik() {
    System.out.print("Masukkan kata kunci pencarian pemilik: ");
    String key = scanner.nextLine().toLowerCase();
    boolean ditemukan = false;
    for (Pemilik p : daftarPemilik) {
        if (p.getNama().toLowerCase().contains(key) ||
            p.getAlamat().toLowerCase().contains(key) ||
            p.getNoHp().toLowerCase().contains(key)) {
            System.out.println(p);
            ditemukan = true;
        }
    }
    if (!ditemukan) System.out.println("❌ Pemilik tidak ditemukan.");
}
    // ------------------ PETUGAS ------------------
    public void tambahPetugas() {
        System.out.print("Nama petugas: ");
        String nama = scanner.nextLine();
        System.out.print("Jenis kelamin: ");
        String jk = scanner.nextLine();
        System.out.print("Umur: ");
        int umur = readIntSafe();
        daftarPetugas.add(new Petugas(nama, jk, umur));
        System.out.println("✅ Petugas berhasil ditambahkan!");
    }

    public void lihatPetugas() {
        System.out.println("\n📋 Daftar Petugas:");
        if (daftarPetugas.isEmpty()) {
            System.out.println("Belum ada petugas.");
            return;
        }
        for (int i = 0; i < daftarPetugas.size(); i++) {
            System.out.println((i + 1) + ". " + daftarPetugas.get(i));
        }
    }

    public void ubahPetugas() {
        lihatPetugas();
        if (daftarPetugas.isEmpty()) return;
        System.out.print("Masukkan nomor petugas yang ingin diubah: ");
        int idx = readIntSafe();
        if (!validIndex(idx, daftarPetugas.size())) {
            System.out.println("Nomor tidak valid.");
            return;
        }
        Petugas p = daftarPetugas.get(idx - 1);

        System.out.print("Nama baru (" + p.getNama() + ") [tekan Enter untuk tetap]: ");
        String n = scanner.nextLine(); if (!n.isEmpty()) p.setNama(n);

        System.out.print("Jenis kelamin baru (" + p.getJenisKelamin() + ") [tekan Enter untuk tetap]: ");
        String jk = scanner.nextLine(); if (!jk.isEmpty()) p.setJenisKelamin(jk);

        System.out.print("Umur baru (" + p.getUmur() + ") [tekan Enter untuk tetap]: ");
        String u = scanner.nextLine(); if (!u.isEmpty()) {
            try { p.setUmur(Integer.parseInt(u)); } catch (NumberFormatException e) {}
        }

        System.out.println("✅ Data petugas berhasil diubah!");
    }

    public void hapusPetugas() {
        lihatPetugas();
        if (daftarPetugas.isEmpty()) return;
        System.out.print("Masukkan nomor petugas yang akan dihapus: ");
        int idx = readIntSafe();
        if (validIndex(idx, daftarPetugas.size())) {
            daftarPetugas.remove(idx - 1);
            System.out.println("✅ Petugas berhasil dihapus!");
        } else System.out.println("Nomor tidak valid.");
    }

    public void cariPetugas() {
    System.out.print("Masukkan kata kunci pencarian petugas: ");
    String key = scanner.nextLine().toLowerCase();
    boolean ditemukan = false;
    for (Petugas p : daftarPetugas) {
        if (p.getNama().toLowerCase().contains(key) ||
            p.getJenisKelamin().toLowerCase().contains(key)) {
            System.out.println(p);
            ditemukan = true;
        }
    }
    if (!ditemukan) System.out.println("❌ Petugas tidak ditemukan.");
}
    public void cariTransaksi() {
    System.out.print("Masukkan kata kunci pencarian transaksi: ");
    String key = scanner.nextLine().toLowerCase();
    boolean ditemukan = false;
    for (Transaksi t : daftarTransaksi) {
        if (t.getPemilik().getNama().toLowerCase().contains(key) ||
            t.getHewan().getNama().toLowerCase().contains(key) ||
            t.getPetugas().getNama().toLowerCase().contains(key)) {
            System.out.println(t);
            ditemukan = true;
        }
    }
    if (!ditemukan) System.out.println("❌ Transaksi tidak ditemukan.");
}
    // ------------------ TRANSAKSI ------------------
    public void tambahTransaksi() {
        if (daftarPemilik.isEmpty() || daftarHewan.isEmpty() || daftarPetugas.isEmpty()) {
            System.out.println("❌ Data pemilik/hewan/petugas belum lengkap!");
            return;
        }

        System.out.println("Pilih Pemilik:");
        lihatPemilik();
        System.out.print("Nomor pemilik: ");
        int ip = readIntSafe();
        if (!validIndex(ip, daftarPemilik.size())) { System.out.println("Nomor tidak valid."); return; }
        Pemilik pemilik = daftarPemilik.get(ip - 1);

        System.out.println("Pilih Hewan:");
        lihatHewan();
        System.out.print("Nomor hewan: ");
        int ih = readIntSafe();
        if (!validIndex(ih, daftarHewan.size())) { System.out.println("Nomor tidak valid."); return; }
        Hewan hewan = daftarHewan.get(ih - 1);

        System.out.println("Pilih Petugas:");
        lihatPetugas();
        System.out.print("Nomor petugas: ");
        int it = readIntSafe();
        if (!validIndex(it, daftarPetugas.size())) { System.out.println("Nomor tidak valid."); return; }
        Petugas petugas = daftarPetugas.get(it - 1);

        System.out.print("Tanggal Masuk (YYYY-MM-DD): ");
        String tglMasuk = scanner.nextLine();
        System.out.print("Tanggal Keluar (YYYY-MM-DD): ");
        String tglKeluar = scanner.nextLine();
        System.out.print("Biaya: ");
        double biaya = readDoubleSafe();

        daftarTransaksi.add(new Transaksi(pemilik, hewan, petugas, tglMasuk, tglKeluar, biaya));
        System.out.println("✅ Transaksi berhasil ditambahkan!");
    }

    public void lihatTransaksi() {
        System.out.println("\n📋 Daftar Transaksi:");
        if (daftarTransaksi.isEmpty()) {
            System.out.println("Belum ada transaksi.");
            return;
        }
        for (int i = 0; i < daftarTransaksi.size(); i++) {
            System.out.println((i + 1) + ". " + daftarTransaksi.get(i));
        }
    }

    public void ubahTransaksi() {
        lihatTransaksi();
        if (daftarTransaksi.isEmpty()) return;
        System.out.print("Masukkan nomor transaksi yang ingin diubah: ");
        int idx = readIntSafe();
        if (!validIndex(idx, daftarTransaksi.size())) { System.out.println("Nomor tidak valid."); return; }

        Transaksi t = daftarTransaksi.get(idx - 1);

        System.out.println("Pilih pemilik baru (0 = tetap):");
        lihatPemilik();
        System.out.print("Nomor pemilik: ");
        int ip = readIntSafe();
        if (ip != 0) {
            if (!validIndex(ip, daftarPemilik.size())) { System.out.println("Nomor tidak valid."); return; }
            t.setPemilik(daftarPemilik.get(ip - 1));
        }

        System.out.println("Pilih hewan baru (0 = tetap):");
        lihatHewan();
        System.out.print("Nomor hewan: ");
        int ih = readIntSafe();
        if (ih != 0) {
            if (!validIndex(ih, daftarHewan.size())) { System.out.println("Nomor tidak valid."); return; }
            t.setHewan(daftarHewan.get(ih - 1));
        }

        System.out.println("Pilih petugas baru (0 = tetap):");
        lihatPetugas();
        System.out.print("Nomor petugas: ");
        int it = readIntSafe();
        if (it != 0) {
            if (!validIndex(it, daftarPetugas.size())) { System.out.println("Nomor tidak valid."); return; }
            t.setPetugas(daftarPetugas.get(it - 1));
        }

        System.out.print("Tanggal Masuk (" + t.getTanggalMasuk() + ") [tekan Enter untuk tetap]: ");
        String tm = scanner.nextLine(); if (!tm.isEmpty()) t.setTanggalMasuk(tm);

        System.out.print("Tanggal Keluar (" + t.getTanggalKeluar() + ") [tekan Enter untuk tetap]: ");
        String tk = scanner.nextLine(); if (!tk.isEmpty()) t.setTanggalKeluar(tk);

        System.out.print("Biaya (" + t.getBiaya() + ") [tekan Enter untuk tetap]: ");
        String bStr = scanner.nextLine();
        if (!bStr.isEmpty()) {
            try { t.setBiaya(Double.parseDouble(bStr)); }
            catch (NumberFormatException e) { System.out.println("Input biaya invalid, tetap menggunakan nilai lama."); }
        }

        System.out.println("✅ Data transaksi berhasil diubah!");
    }

    public void hapusTransaksi() {
        lihatTransaksi();
        if (daftarTransaksi.isEmpty()) return;
        System.out.print("Masukkan nomor transaksi yang akan dihapus: ");
        int idx = readIntSafe();
        if (validIndex(idx, daftarTransaksi.size())) {
            daftarTransaksi.remove(idx - 1);
            System.out.println("✅ Transaksi berhasil dihapus!");
        } else System.out.println("Nomor tidak valid.");
    }

    // ------------------ Helpers ------------------
    private int readIntSafe() {
        while (true) {
            String line = scanner.nextLine();
            try {
                return Integer.parseInt(line.trim());
            } catch (Exception e) {
                System.out.print("Input harus angka. Coba lagi: ");
            }
        }
    }

    private double readDoubleSafe() {
        while (true) {
            String line = scanner.nextLine();
            try {
                return Double.parseDouble(line.trim());
            } catch (Exception e) {
                System.out.print("Input harus angka (desimal). Coba lagi: ");
            }
        }
    }

    private boolean validIndex(int idx, int size) {
        return idx > 0 && idx <= size;
    }
}
