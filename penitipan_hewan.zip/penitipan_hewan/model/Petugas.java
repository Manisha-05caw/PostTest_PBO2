package penitipan_hewan.model;

public class Petugas {
    private String nama;
    private String jenisKelamin;
    private int umur;

    public Petugas(String nama, String jenisKelamin, int umur) {
        this.nama = nama;
        this.jenisKelamin = jenisKelamin;
        this.umur = umur;
    }

    public String getNama() { return nama; }
    public void setNama(String nama) { this.nama = nama; }

    public String getJenisKelamin() { return jenisKelamin; }
    public void setJenisKelamin(String jenisKelamin) { this.jenisKelamin = jenisKelamin; }

    public int getUmur() { return umur; }
    public void setUmur(int umur) { this.umur = umur; }

    @Override
    public String toString() {
        return "Nama: " + nama + ", Jenis Kelamin: " + jenisKelamin + ", Umur: " + umur;
    }
}
