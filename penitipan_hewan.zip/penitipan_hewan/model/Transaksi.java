package penitipan_hewan.model;

public class Transaksi {
    private Pemilik pemilik;
    private Hewan hewan;
    private Petugas petugas;
    private String tanggalMasuk;
    private String tanggalKeluar;
    private double biaya;

    public Transaksi(Pemilik pemilik, Hewan hewan, Petugas petugas,
                     String tanggalMasuk, String tanggalKeluar, double biaya) {
        this.pemilik = pemilik;
        this.hewan = hewan;
        this.petugas = petugas;
        this.tanggalMasuk = tanggalMasuk;
        this.tanggalKeluar = tanggalKeluar;
        this.biaya = biaya;
    }

    public Pemilik getPemilik() { return pemilik; }
    public void setPemilik(Pemilik pemilik) { this.pemilik = pemilik; }

    public Hewan getHewan() { return hewan; }
    public void setHewan(Hewan hewan) { this.hewan = hewan; }

    public Petugas getPetugas() { return petugas; }
    public void setPetugas(Petugas petugas) { this.petugas = petugas; }

    public String getTanggalMasuk() { return tanggalMasuk; }
    public void setTanggalMasuk(String tanggalMasuk) { this.tanggalMasuk = tanggalMasuk; }

    public String getTanggalKeluar() { return tanggalKeluar; }
    public void setTanggalKeluar(String tanggalKeluar) { this.tanggalKeluar = tanggalKeluar; }

    public double getBiaya() { return biaya; }
    public void setBiaya(double biaya) { this.biaya = biaya; }

    @Override
    public String toString() {
        return "Transaksi: { Pemilik=" + pemilik.getNama() +
               ", Hewan=" + hewan.getNama() +
               ", Petugas=" + petugas.getNama() +
               ", Masuk=" + tanggalMasuk +
               ", Keluar=" + tanggalKeluar +
               ", Biaya=" + biaya + " }";
    }
}
